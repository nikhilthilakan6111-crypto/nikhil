/**
 * NAIL YOUR GOAL - Youth Clarity Workshop
 * Interactive JavaScript Engine
 * Handles Countdown, WhatsApp, Social Links, Form Submission & Price Reveal (₹1200)
 */

// ==========================================
// 1. CONFIGURATION: SOCIAL & WHATSAPP
// ==========================================
const CONFIG = {
  // Configurable URLs - User can easily change these
  facebookUrl: "https://facebook.com/nailyourgoal",
  instagramUrl: "https://instagram.com/nailyourgoal",
  whatsappNumber: "918590820175",
  workshopDate: "2026-10-31T09:00:00+05:30", // Saturday, Oct 31, 2026 9:00 AM IST
  workshopPrice: "₹1,200",
  originalPrice: "₹3,500",
  venue: "Hotel Rukmini, Angamaly, Kerala"
};

// ==========================================
// 2. INITIALIZE SOCIAL LINKS & WHATSAPP
// ==========================================
function initSocialAndWhatsappLinks() {
  // Update all Facebook links
  document.querySelectorAll('.js-facebook-link').forEach(link => {
    link.href = CONFIG.facebookUrl;
    link.target = "_blank";
    link.rel = "noopener noreferrer";
  });

  // Update all Instagram links
  document.querySelectorAll('.js-instagram-link').forEach(link => {
    link.href = CONFIG.instagramUrl;
    link.target = "_blank";
    link.rel = "noopener noreferrer";
  });

  // Update default WhatsApp links
  const defaultWaMsg = encodeURIComponent("Hi Dr. Joseph, I would like to register for the Nail Your Goal Youth Clarity Workshop on Saturday, Oct 31 at Hotel Rukmini, Angamaly.");
  const defaultWaUrl = `https://wa.me/${CONFIG.whatsappNumber}?text=${defaultWaMsg}`;

  document.querySelectorAll('.js-whatsapp-link').forEach(link => {
    link.href = defaultWaUrl;
    link.target = "_blank";
    link.rel = "noopener noreferrer";
  });
}

// ==========================================
// 3. COUNTDOWN TIMER ENGINE
// ==========================================
function initCountdownTimer() {
  const targetTime = new Date(CONFIG.workshopDate).getTime();

  const daysEl = document.getElementById('timer-days');
  const hoursEl = document.getElementById('timer-hours');
  const minutesEl = document.getElementById('timer-minutes');
  const secondsEl = document.getElementById('timer-seconds');

  if (!daysEl || !hoursEl || !minutesEl || !secondsEl) return;

  function updateTimer() {
    const now = new Date().getTime();
    const distance = targetTime - now;

    if (distance < 0) {
      daysEl.innerText = "00";
      hoursEl.innerText = "00";
      minutesEl.innerText = "00";
      secondsEl.innerText = "00";
      const statusTitle = document.getElementById('countdown-status-text');
      if (statusTitle) statusTitle.innerText = "Workshop in Progress!";
      return;
    }

    const days = Math.floor(distance / (1000 * 60 * 60 * 24));
    const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((distance % (1000 * 60)) / 1000);

    daysEl.innerText = String(days).padStart(2, '0');
    hoursEl.innerText = String(hours).padStart(2, '0');
    minutesEl.innerText = String(minutes).padStart(2, '0');
    secondsEl.innerText = String(seconds).padStart(2, '0');
  }

  updateTimer();
  setInterval(updateTimer, 1000);
}

// ==========================================
// 4. REGISTRATION FORM & ₹1200 PRICE REVEAL
// ==========================================
function initLeadFormAndPriceReveal() {
  const form = document.getElementById('workshop-lead-form');
  const modal = document.getElementById('price-reveal-modal');
  const closeModalBtn = document.getElementById('close-price-modal');
  const registeredNameSpan = document.getElementById('reveal-student-name');
  const finalWaActionBtn = document.getElementById('modal-wa-confirm-btn');

  if (!form || !modal) return;

  form.addEventListener('submit', function(e) {
    e.preventDefault();

    const fullName = document.getElementById('lead-name').value.trim();
    const phone = document.getElementById('lead-phone').value.trim();
    const email = document.getElementById('lead-email').value.trim();
    const status = document.getElementById('lead-status').value;
    const city = document.getElementById('lead-city').value.trim() || 'Kerala';

    // Simple validation
    if (!fullName || !phone) {
      alert("Please fill in your Full Name and WhatsApp Number to proceed.");
      return;
    }

    if (phone.length < 10) {
      alert("Please enter a valid 10-digit WhatsApp number.");
      return;
    }

    // Populate user name in modal
    if (registeredNameSpan) {
      registeredNameSpan.innerText = fullName;
    }

    // Build personalized WhatsApp confirmation link
    const personalizedMsg = encodeURIComponent(
      `Hello Dr. Joseph Sudhip,\n\nI have submitted the workshop registration form.\n\n` +
      `*Registration Details:*\n` +
      `• Name: ${fullName}\n` +
      `• Contact: ${phone}\n` +
      `• Email: ${email || 'Not provided'}\n` +
      `• Category: ${status}\n` +
      `• City: ${city}\n\n` +
      `I am ready to confirm my subsidized pass for *₹1,200* for the Nail Your Goal Workshop at Hotel Rukmini, Angamaly on Oct 31, 2026. Please share the payment confirmation instructions.`
    );

    const waCheckoutUrl = `https://wa.me/${CONFIG.whatsappNumber}?text=${personalizedMsg}`;

    if (finalWaActionBtn) {
      finalWaActionBtn.href = waCheckoutUrl;
    }

    // Trigger celebratory confetti animation
    triggerConfetti();

    // Reveal price modal
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';

    // Log lead submission to console (Ready for Meta Pixel / CAPI tracking)
    console.log("Meta Lead Generated:", { fullName, phone, email, status, city, fee: CONFIG.workshopPrice });
    if (typeof fbq === 'function') {
      fbq('track', 'Lead', {
        content_name: 'Nail Your Goal Workshop',
        value: 1200,
        currency: 'INR'
      });
    }
  });

  // Close modal handler
  if (closeModalBtn) {
    closeModalBtn.addEventListener('click', function() {
      modal.classList.remove('active');
      document.body.style.overflow = '';
    });
  }

  // Click outside modal card to close
  modal.addEventListener('click', function(e) {
    if (e.target === modal) {
      modal.classList.remove('active');
      document.body.style.overflow = '';
    }
  });
}

// Lightweight Confetti Trigger
function triggerConfetti() {
  const count = 60;
  const container = document.body;

  for (let i = 0; i < count; i++) {
    const confetti = document.createElement('div');
    confetti.className = 'confetti-piece';
    const colors = ['#0066FF', '#FFC727', '#25D366', '#DC2626', '#8B5CF6'];
    const randomColor = colors[Math.floor(Math.random() * colors.length)];

    confetti.style.cssText = `
      position: fixed;
      top: -10px;
      left: ${Math.random() * 100}vw;
      width: ${Math.random() * 8 + 6}px;
      height: ${Math.random() * 14 + 8}px;
      background-color: ${randomColor};
      z-index: 9999;
      pointer-events: none;
      opacity: 0.9;
      transform: rotate(${Math.random() * 360}deg);
      transition: transform 2.5s cubic-bezier(0.25, 1, 0.5, 1), top 2.5s cubic-bezier(0.25, 1, 0.5, 1), opacity 2.5s ease-out;
    `;

    container.appendChild(confetti);

    setTimeout(() => {
      confetti.style.top = `${window.innerHeight + 20}px`;
      confetti.style.transform = `rotate(${Math.random() * 720}deg) scale(0.6)`;
      confetti.style.opacity = '0';
    }, 20);

    setTimeout(() => {
      confetti.remove();
    }, 2800);
  }
}

// ==========================================
// 5. FAQ ACCORDION ENGINE
// ==========================================
function initFaqAccordion() {
  const faqItems = document.querySelectorAll('.faq-item');

  faqItems.forEach(item => {
    const header = item.querySelector('.faq-header');
    header.addEventListener('click', () => {
      const isActive = item.classList.contains('active');

      // Close other items
      faqItems.forEach(otherItem => {
        if (otherItem !== item) {
          otherItem.classList.remove('active');
        }
      });

      // Toggle current
      item.classList.toggle('active', !isActive);
    });
  });
}

// ==========================================
// 6. MOBILE DRAWER NAVIGATION
// ==========================================
function initMobileNav() {
  const hamburgerBtn = document.getElementById('hamburger-toggle');
  const drawer = document.getElementById('mobile-drawer');
  const overlay = document.getElementById('mobile-overlay');
  const drawerLinks = document.querySelectorAll('.mobile-nav-links a');

  function openDrawer() {
    drawer.classList.add('open');
    overlay.classList.add('open');
    document.body.style.overflow = 'hidden';
  }

  function closeDrawer() {
    drawer.classList.remove('open');
    overlay.classList.remove('open');
    document.body.style.overflow = '';
  }

  if (hamburgerBtn && drawer && overlay) {
    hamburgerBtn.addEventListener('click', openDrawer);
    overlay.addEventListener('click', closeDrawer);

    drawerLinks.forEach(link => {
      link.addEventListener('click', closeDrawer);
    });
  }
}

// ==========================================
// 7. INTERACTIVE 60-SEC CLARITY DIAGNOSTIC
// ==========================================
function initClarityDiagnostic() {
  const quizSteps = document.querySelectorAll('.quiz-step');
  const optionButtons = document.querySelectorAll('.quiz-option-btn');
  const restartBtn = document.getElementById('restart-quiz-btn');

  let currentStep = 1;
  let totalScore = 0;

  optionButtons.forEach(btn => {
    btn.addEventListener('click', function() {
      const points = parseInt(this.getAttribute('data-points') || '10', 10);
      totalScore += points;

      const parentStep = this.closest('.quiz-step');
      parentStep.classList.remove('active');

      currentStep++;
      const nextStep = document.querySelector(`.quiz-step[data-step="${currentStep}"]`);

      if (nextStep) {
        nextStep.classList.add('active');
      } else {
        // Show result step
        const resultStep = document.querySelector('.quiz-step[data-step="result"]');
        if (resultStep) {
          resultStep.classList.add('active');
          const scoreDisplay = document.getElementById('quiz-final-score');
          const scoreMessage = document.getElementById('quiz-result-message');

          if (scoreDisplay) scoreDisplay.innerText = `${Math.min(100, Math.max(25, totalScore))}%`;
          if (scoreMessage) {
            scoreMessage.innerText = totalScore < 50
              ? "You have high potential but are currently dealing with analysis paralysis and lack of direction. Dr. Joseph's 9-Step Action Blueprint is built specifically to break this loop!"
              : "You have strong aspirations, but without a proven execution framework, you risk burnout and second-guessing. Join the workshop to lock in your masterplan!";
          }
        }
      }
    });
  });

  if (restartBtn) {
    restartBtn.addEventListener('click', function() {
      currentStep = 1;
      totalScore = 0;
      quizSteps.forEach(step => step.classList.remove('active'));
      const firstStep = document.querySelector('.quiz-step[data-step="1"]');
      if (firstStep) firstStep.classList.add('active');
    });
  }
}

// ==========================================
// 8. LIVE META PROOF POPUPS (SOCIAL PROOF)
// ==========================================
function initSocialProofToasts() {
  const popup = document.getElementById('recent-lead-popup');
  const nameEl = document.getElementById('popup-lead-name');
  const timeEl = document.getElementById('popup-lead-time');

  if (!popup || !nameEl || !timeEl) return;

  const mockAttendees = [
    { name: "Arjun K.", location: "Ernakulam", time: "4 mins ago" },
    { name: "Sneha Nair", location: "Aluva", time: "9 mins ago" },
    { name: "Joel Mathew", location: "Angamaly", time: "14 mins ago" },
    { name: "Aparna R.", location: "Thrissur", time: "22 mins ago" },
    { name: "Mohammed Farhan", location: "Kochi", time: "31 mins ago" }
  ];

  let index = 0;

  function showNextPopup() {
    const attendee = mockAttendees[index];
    nameEl.innerText = `${attendee.name} from ${attendee.location}`;
    timeEl.innerText = `Reserved seat • ${attendee.time}`;

    popup.classList.add('show');

    setTimeout(() => {
      popup.classList.remove('show');
    }, 4500);

    index = (index + 1) % mockAttendees.length;
  }

  // First popup after 4 seconds, then repeat every 18 seconds
  setTimeout(() => {
    showNextPopup();
    setInterval(showNextPopup, 18000);
  }, 4000);
}

// ==========================================
// 9. VIDEO MODAL ENGINE
// ==========================================
function initVideoModal() {
  const videoBtn = document.getElementById('watch-video-btn');
  const videoModal = document.getElementById('video-modal');
  const closeVideoBtn = document.getElementById('close-video-modal');
  const videoIframe = document.getElementById('promo-video-frame');

  if (!videoBtn || !videoModal) return;

  videoBtn.addEventListener('click', function(e) {
    e.preventDefault();
    videoModal.classList.add('active');
    document.body.style.overflow = 'hidden';
    // Sample high-quality inspirational preview video
    if (videoIframe && !videoIframe.src) {
      videoIframe.src = "https://www.youtube-nocookie.com/embed/dQw4w9WgXcQ?autoplay=1";
    }
  });

  function closeVideo() {
    videoModal.classList.remove('active');
    document.body.style.overflow = '';
    if (videoIframe) {
      videoIframe.src = "";
    }
  }

  if (closeVideoBtn) closeVideoBtn.addEventListener('click', closeVideo);
  videoModal.addEventListener('click', function(e) {
    if (e.target === videoModal) closeVideo();
  });
}

// ==========================================
// RUN ALL INITIALIZATIONS ON DOM READY
// ==========================================
document.addEventListener('DOMContentLoaded', () => {
  initSocialAndWhatsappLinks();
  initCountdownTimer();
  initLeadFormAndPriceReveal();
  initFaqAccordion();
  initMobileNav();
  initClarityDiagnostic();
  initSocialProofToasts();
  initVideoModal();
  console.log("Nail Your Goal Landing Page Engine successfully initialized.");
});
